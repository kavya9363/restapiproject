package com.example.tablecreation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TablecreationApplicationTests {

	@Test
	void contextLoads() {
	}

}
